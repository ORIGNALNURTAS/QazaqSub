"""
Видео файлынан Whisper моделіне қажетті форматта (16kHz, моно, WAV)
аудио дорожканы бөліп алатын модуль.
"""
import os
import ffmpeg


def extract_audio(video_path: str, output_dir: str = "temp") -> str:
    """
    Видеодан аудионы бөліп алып, .wav файл жолын қайтарады.

    :param video_path: Бастапқы видео файлының жолы
    :param output_dir: Аудио файл сақталатын қалта
    :return: Шыққан .wav файлының толық жолы
    """
    os.makedirs(output_dir, exist_ok=True)
    base_name = os.path.splitext(os.path.basename(video_path))[0]
    audio_path = os.path.join(output_dir, f"{base_name}.wav")

    (
        ffmpeg
        .input(video_path)
        .output(
            audio_path,
            ac=1,            # моно арна
            ar=16000,        # 16kHz — Whisper талап ететін жиілік
            format="wav",
        )
        .overwrite_output()
        .run(quiet=True)
    )

    return audio_path
