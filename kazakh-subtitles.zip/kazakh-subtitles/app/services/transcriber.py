"""
OpenAI Whisper моделі арқылы аудионы мәтінге түрлендіретін модуль.
Нәтиже — уақыт белгілері бар сегменттер тізімі, бұл субтитр жасау үшін қажет.
"""
from functools import lru_cache
from typing import List, TypedDict

import whisper


class Segment(TypedDict):
    start: float
    end: float
    text: str


@lru_cache(maxsize=1)
def _load_model(model_size: str = "base"):
    """
    Whisper моделін бір рет жүктеп, кэштен қайтарады (сервер әр сұранымда
    қайта жүктемеу үшін). Өндірістік ортада model_size="small"/"medium"/
    "large-v3" дәлдігі жоғары нұсқаларды қолдануға болады.
    """
    return whisper.load_model(model_size)


def transcribe_audio(
    audio_path: str,
    model_size: str = "base",
    source_language: str | None = None,
) -> List[Segment]:
    """
    Аудио файлын транскрипциялап, сегменттер тізімін қайтарады.

    :param audio_path: .wav аудио файлының жолы
    :param model_size: Whisper моделінің өлшемі (tiny/base/small/medium/large)
    :param source_language: Бастапқы тіл коды (мысалы, "en", "ru"); белгісіз
                             болса None қалдырыңыз — Whisper өзі анықтайды
    :return: {"start": ..., "end": ..., "text": ...} түріндегі сегменттер тізімі
    """
    model = _load_model(model_size)

    result = model.transcribe(
        audio_path,
        language=source_language,
        task="transcribe",
        verbose=False,
    )

    segments: List[Segment] = [
        {
            "start": seg["start"],
            "end": seg["end"],
            "text": seg["text"].strip(),
        }
        for seg in result["segments"]
    ]

    return segments
