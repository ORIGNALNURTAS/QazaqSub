"""
Видео сілтемесі бойынша файлды жергілікті дискіге жүктеп алатын модуль.
yt-dlp кітапханасы YouTube және басқа да көптеген платформаларды қолдайды.
"""
import os
import uuid
import yt_dlp


def download_video(video_url: str, output_dir: str = "temp") -> str:
    """
    Берілген URL бойынша видеоны жүктеп, жергілікті файл жолын қайтарады.

    :param video_url: Видеоның сілтемесі (мысалы, YouTube URL)
    :param output_dir: Жүктелген файлдар сақталатын қалта
    :return: Жүктелген видео файлының толық жолы
    """
    os.makedirs(output_dir, exist_ok=True)
    file_id = str(uuid.uuid4())
    output_template = os.path.join(output_dir, f"{file_id}.%(ext)s")

    ydl_opts = {
        "format": "bestvideo[height<=720]+bestaudio/best[height<=720]",
        "outtmpl": output_template,
        "quiet": True,
        "no_warnings": True,
        "merge_output_format": "mp4",
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(video_url, download=True)
        downloaded_path = ydl.prepare_filename(info)

        # merge_output_format mp4-ке ауыстырғандықтан кеңейтімді түзетеміз
        base, _ = os.path.splitext(downloaded_path)
        mp4_path = base + ".mp4"
        if os.path.exists(mp4_path):
            return mp4_path
        return downloaded_path
