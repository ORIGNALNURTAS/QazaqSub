"""
Уақыт белгілері бар сегменттерден стандартты .srt субтитр файлын құрастырады.
"""
import os
from typing import List

import srt
from datetime import timedelta

from app.services.transcriber import Segment


def generate_srt(segments: List[Segment], output_path: str) -> str:
    """
    Сегменттерден .srt файлын жасайды.

    :param segments: {"start", "end", "text"} өрістері бар сегменттер тізімі
    :param output_path: Шығыс .srt файлының жолы
    :return: Жазылған файлдың жолы
    """
    subtitles = []
    for idx, seg in enumerate(segments, start=1):
        subtitles.append(
            srt.Subtitle(
                index=idx,
                start=timedelta(seconds=seg["start"]),
                end=timedelta(seconds=seg["end"]),
                content=seg["text"],
            )
        )

    srt_content = srt.compose(subtitles)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(srt_content)

    return output_path
